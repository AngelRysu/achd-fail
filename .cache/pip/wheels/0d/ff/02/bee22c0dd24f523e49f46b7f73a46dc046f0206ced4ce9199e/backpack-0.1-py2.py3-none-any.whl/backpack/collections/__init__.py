# -*- coding: utf-8 -*-

from .collection import Collection


def collect(items):
    return Collection(items)
